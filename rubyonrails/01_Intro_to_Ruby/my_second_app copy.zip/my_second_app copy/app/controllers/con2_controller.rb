class Con2Controller < ApplicationController
  def index
  end
end
