class TodoList < ActiveRecord::Migration
  def change
  end
end
